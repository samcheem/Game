import express from 'express';
import http from 'node:http';
import {Server} from 'socket.io';

import crypto from 'node:crypto';
const app=express(),server=http.createServer(app),io=new Server(server);
// Static game assets are served by Netlify's CDN from public/.
const rooms=new Map(), alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const code=()=>Array.from({length:6},()=>alphabet[crypto.randomInt(alphabet.length)]).join('');
const choices=['🐕 Cheem','💎 Diamond','🚀 Rocket','🍀 Clover','👑 Crown','🔥 Flame','🍕 Pizza','⚡ Lightning'];
const clean=s=>String(s||'Player').replace(/[^\w -]/g,'').slice(0,20)||'Player';
const roomView=r=>({code:r.code,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,cash:p.cash,shieldUntil:p.shieldUntil}))});
function broadcast(r){io.to(r.code).emit('roomState',roomView(r))}
function leave(socket){const code=socket.data.room, r=rooms.get(code);if(!r)return;r.players.delete(socket.id);socket.leave(code);socket.data.room=null;if(!r.players.size)rooms.delete(code);else broadcast(r)}
io.on('connection',socket=>{
 socket.on('createRoom',({name}={},ack=()=>{})=>{leave(socket);let c;do{c=code()}while(rooms.has(c));const r={code:c,players:new Map(),attacks:new Map()};rooms.set(c,r);socket.data.room=c;r.players.set(socket.id,{id:socket.id,name:clean(name),cash:0,shieldUntil:0});socket.join(c);ack({ok:true,code:c,id:socket.id});broadcast(r)});
 socket.on('joinRoom',({name,code:c}={},ack=()=>{})=>{c=String(c||'').trim().toUpperCase();const r=rooms.get(c);if(!r)return ack({error:'Room not found'});if(r.players.size>=12)return ack({error:'Room full (12 players)'});leave(socket);socket.data.room=c;r.players.set(socket.id,{id:socket.id,name:clean(name),cash:0,shieldUntil:0});socket.join(c);ack({ok:true,code:c,id:socket.id});broadcast(r)});
 socket.on('syncCash',(amount)=>{const r=rooms.get(socket.data.room),p=r?.players.get(socket.id);if(!p)return;p.cash=Math.max(0,Math.min(1e15,Number(amount)||0));broadcast(r)});
 socket.on('shield',(_,ack=()=>{})=>{const r=rooms.get(socket.data.room),p=r?.players.get(socket.id);if(!p)return ack({error:'Not in room'});if(p.cash<5000)return ack({error:'Need $5,000'});p.cash-=5000;p.shieldUntil=Date.now()+120000;socket.emit('cashDelta',-5000);ack({ok:true});broadcast(r)});
 socket.on('attack',({targetId}={},ack=()=>{})=>{const r=rooms.get(socket.data.room),attacker=r?.players.get(socket.id),target=r?.players.get(targetId);if(!attacker||!target||targetId===socket.id)return ack({error:'Invalid target'});if(target.shieldUntil>Date.now())return ack({error:'Target is shielded'});if(attacker.cash<100)return ack({error:'Need $100 to launch an attack'});const now=Date.now(),last=r.attacks.get(socket.id);if(last&&now-last<10000)return ack({error:'Wait 10 seconds between attacks'});r.attacks.set(socket.id,now);attacker.cash-=100;socket.emit('cashDelta',-100);const opts=[...choices].sort(()=>Math.random()-.5).slice(0,4),answer=crypto.randomInt(4);const challengeId=crypto.randomUUID();socket.data.challenge={challengeId,targetId,answer,expires:now+15000};ack({ok:true,challengeId,options:opts,expires:now+15000});broadcast(r)});
 socket.on('guess',({challengeId,choice}={},ack=()=>{})=>{const r=rooms.get(socket.data.room),a=r?.players.get(socket.id),c=socket.data.challenge,t=r?.players.get(c?.targetId);if(!a||!c||!t||c.challengeId!==challengeId||Date.now()>c.expires)return ack({error:'Challenge expired'});socket.data.challenge=null;const success=choice===c.answer&&t.shieldUntil<Date.now();let stolen=0;if(success){stolen=Math.min(t.cash,Math.max(100,Math.floor(t.cash*.05)),250000);t.cash-=stolen;a.cash+=stolen;socket.emit('cashDelta',stolen);io.to(t.id).emit('cashDelta',-stolen);io.to(t.id).emit('attackNotice',`${a.name} hacked your vault for $${stolen.toLocaleString()}!`)}ack({ok:true,success,stolen});broadcast(r)});
 socket.on('disconnect',()=>leave(socket));socket.on('leaveRoom',()=>leave(socket));
});
// Netlify Server mounts this HTTP server and handles Socket.IO upgrades.
export default server;
