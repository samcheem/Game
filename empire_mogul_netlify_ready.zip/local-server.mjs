import server from "./netlify/server/index.mjs";
const port=Number(process.env.PORT)||3000;
server.listen(port,()=>console.log(`Visit http://localhost:${port}`));
