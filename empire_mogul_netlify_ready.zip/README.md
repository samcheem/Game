# Empire Mogul — Netlify Website

A browser-based tycoon game with solo offline play and live multiplayer room codes, gambling using fictional in-game dollars, casino ownership, luxury purchases, taxes, business upkeep and rebirth.

## Deploy to Netlify from a Mac

1. Create a GitHub repository and upload **the contents of this folder** to the repo root.
2. In Netlify, choose **Add new project → Import an existing project → GitHub**, select that repository, and deploy. Or link the repo under Project configuration → Build & deploy on an existing empty Netlify project.
3. Netlify detects `netlify.toml`, installs npm dependencies, publishes `public/`, and runs the Socket.IO backend via **Netlify Server (Early Access)**. Node.js 24+ is configured for builds.
4. Once the deploy says **Published**, open the `https://...netlify.app` link. Share the URL and let friends join with a six-character room code.

You need Netlify Server access on your team. This is an Early Access feature and can have limitations. **An HTML-only drag-and-drop deploy will not deploy the multiplayer server**; Git continuous deployment or a suitable Netlify CLI deploy is required.

## Local test

`npm install && npm start` then browse to `http://localhost:3000` (server runs Socket.IO; for local static assets, opening `public/index.html` directly works for solo mode; to serve everything locally use `npx netlify dev` with Node.js 24+ and Netlify CLI 27.17.0+).

## Limitations

- Cash is calculated and stored in the player's browser. Online cash sync is **not cheat-proof**. Do not treat multiplayer as competitive with real value.
- Room state is in server memory, limited to 12 players per room, and resets when Netlify Server restarts or scales down.
- No real-money gambling, real account hacking, actual cryptocurrencies, or actual password guessing.
- A local save is scoped to the browser/domain; it does not automatically move from prior HTML files to the new website.
